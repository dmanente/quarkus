package com.redhat.training.expense;

public class FraudScore {
    public int score;

    public FraudScore(int score) {
        this.score = score;
    }
}
