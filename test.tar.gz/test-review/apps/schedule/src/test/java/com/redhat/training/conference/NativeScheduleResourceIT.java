package com.redhat.training.conference;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class NativeScheduleResourceIT extends ScheduleResourceTest {

    // Execute the same tests but in native mode.
}
