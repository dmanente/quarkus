package com.redhat.training.speaker.idgenerator;

public interface IdGenerator {
    public String generate();
}
