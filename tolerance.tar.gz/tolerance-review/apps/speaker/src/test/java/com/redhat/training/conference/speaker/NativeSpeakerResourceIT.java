package com.redhat.training.conference.speaker;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class NativeSpeakerResourceIT extends SpeakerResourceTest {

    // Execute the same tests but in native mode.
}
