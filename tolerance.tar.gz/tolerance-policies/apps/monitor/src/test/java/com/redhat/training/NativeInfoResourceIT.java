package com.redhat.training;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class NativeInfoResourceIT extends MonitorResourceTest {

    // Execute the same tests but in native mode.
}
