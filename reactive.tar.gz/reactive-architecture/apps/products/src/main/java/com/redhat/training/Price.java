package com.redhat.training;

import java.util.Date;

public class Price {
    public Date date;
    public Double price;
}
