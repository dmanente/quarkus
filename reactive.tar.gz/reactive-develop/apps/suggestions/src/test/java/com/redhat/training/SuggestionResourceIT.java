package com.redhat.training;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class SuggestionResourceIT extends SuggestionResourceTest {
    // Execute the same tests but in packaged mode.
}
