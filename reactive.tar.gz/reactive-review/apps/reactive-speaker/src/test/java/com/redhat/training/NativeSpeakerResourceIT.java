package com.redhat.training;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class NativeSpeakerResourceIT extends SpeakerResourceTest {

    // Execute the same tests but in native mode.
}
