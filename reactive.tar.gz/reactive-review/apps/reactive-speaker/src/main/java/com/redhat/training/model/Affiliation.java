package com.redhat.training.model;

public enum Affiliation {
    RED_HAT,
    LINUX_FOUNDATION,
    GNOME_FOUNDATION,
    NONE
}
