export interface Speaker {
    id?: number;
    uuid?: string;
    nameFirst: string;
    nameLast: string;
}
