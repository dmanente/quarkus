INSERT INTO EXPENSE (UUID,AMOUNT,NAME,PAYMENTMETHOD) 
VALUES 
  ('3f1817f2-3dcf-472f-a8b2-77bfe25e79d1', 10,'Kubernetes Patterns', 0),
  ('4fe78f4f-3335-4585-8677-5d9c8bbb539e', 15,'Red Hat OpenShift for Developers', 0),
  ('02d13404-1677-45f6-862b-93e5f87e27d3', 15,'Podman in Action', 0);
