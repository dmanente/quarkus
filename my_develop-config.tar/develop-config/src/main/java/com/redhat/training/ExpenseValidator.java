package com.redhat.training;

import jakarta.enterprise.context.ApplicationScoped;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@ApplicationScoped
public class ExpenseValidator {

    //private static final boolean DEBUG_ENABLED = true;
    @ConfigProperty(name = "debug-enabled", defaultValue = "false")
    boolean debug;


    //private static final int RANGE_HIGH = 1000;
    @ConfigProperty(name = "range-high")
    int targetRangeHigh;

    //private static final int RANGE_LOW = 250;
    @ConfigProperty(name = "range-low")
    int targetRangeLow;

    
    public void debugRanges() {
        System.out.println("Range - High: " + targetRangeHigh);
        System.out.println("Range - Low: " + targetRangeLow);
    }

    public boolean isValidAmount(int amount) {
        if (debug) {
            debugRanges();
        }

        return amount >= targetRangeLow && amount <= targetRangeHigh;
    }
}
