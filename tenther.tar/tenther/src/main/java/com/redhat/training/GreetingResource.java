package com.redhat.training;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

//@Path("/hello")
@Path("/tenther")
public class GreetingResource {

    /* 
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        return "Hello RESTEasy";
    }
    */

    @GET
    @Path("/{number}")
    @Produces(MediaType.TEXT_PLAIN)
    public String multiply(@PathParam("number") Integer number) {
        return String.valueOf(number * 10) + "\n";
        }
    
}
