export interface SessionRating {
    session: string;
    attendeeId: string;
    rating: number;
}
