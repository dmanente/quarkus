package com.redhat.developer.demos.preference.rest;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativePreferenceResourceIT extends PreferenceResourceTest {

    // Execute the same tests but in native mode.
}