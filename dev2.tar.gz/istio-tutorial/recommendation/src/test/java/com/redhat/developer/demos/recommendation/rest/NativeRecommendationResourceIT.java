package com.redhat.developer.demos.recommendation.rest;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeRecommendationResourceIT extends RecommendationResourceTest {

    // Execute the same tests but in native mode.
}