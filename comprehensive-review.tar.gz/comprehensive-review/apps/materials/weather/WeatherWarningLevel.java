package com.redhat.smartcity.weather;

public enum WeatherWarningLevel {
    Yellow,
    Orange,
    Red
}
