INSERT INTO
    park(id, name, city, status, size)
VALUES
    (1, 'Vondelpark', 'Amsterdam', 1, 800),
    (2, 'Parc du Cinquantenaire', 'Brussels', 1, 700),
    (3, 'Parque Ibirapuera', 'São Paulo', 1, 1000),
    (4, 'Parc Güell', 'Barcelona', 1, 500);

