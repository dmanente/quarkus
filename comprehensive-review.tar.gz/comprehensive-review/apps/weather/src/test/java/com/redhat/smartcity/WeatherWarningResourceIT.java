package com.redhat.smartcity;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class WeatherWarningResourceIT extends WeatherWarningResourceTest {
    // Execute the same tests but in packaged mode.
}
