package com.redhat.smartcity.entities;

public enum WeatherWarningType {
    Rain,
    Snow,
    Wind,
    Storm,
    MaxTemperature,
    MinTemperature,
    DenseFog
}
