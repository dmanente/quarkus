package com.redhat.smartcity.entities;

public enum WeatherWarningLevel {
    Yellow,
    Orange,
    Red
}
