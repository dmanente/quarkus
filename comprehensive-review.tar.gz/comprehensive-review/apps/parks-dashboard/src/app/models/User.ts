export interface User {
    username: string,
    jwt: string
}