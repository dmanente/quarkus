export interface ParkEvent {
    name: string,
    gardenName: string,
    value: number,
    sensorId: number,
    timestamp: Date
}
