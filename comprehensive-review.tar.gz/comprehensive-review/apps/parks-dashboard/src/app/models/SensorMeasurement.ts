export interface SensorMeasurement {
    type: string,
    value: any,
    gardenName: string,
    sensorName: string,
    timestamp: Date
}
