export interface WeatherWarning {
    city: string,
    type: string,
    level: string
}