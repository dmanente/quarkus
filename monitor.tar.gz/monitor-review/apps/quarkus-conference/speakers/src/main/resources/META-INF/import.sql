insert into Speaker (id, uuid, nameFirst, nameLast,organization,biography,twitterHandle) values (nextval('Speaker_SEQ'), 's-1-1', 'Emmanuel', 'Bernard','RedHat','Quarkus founder','emm');
insert into Speaker (id, uuid, nameFirst, nameLast,organization,biography,twitterHandle) values (nextval('Speaker_SEQ'), 's-1-2', 'Clement', 'Escoffier','RedHat','Vert.x guru','clem');
insert into Speaker (id, uuid, nameFirst, nameLast,organization,biography,twitterHandle) values (nextval('Speaker_SEQ'), 's-1-3', 'Alex', 'Soto','RedHat','Lord of the Jars','alex');
insert into Speaker (id, uuid, nameFirst, nameLast,organization,biography,twitterHandle) values (nextval('Speaker_SEQ'), 's-1-4', 'Burr', 'Sutter','RedHat','King of the Summit Demos','burr');
