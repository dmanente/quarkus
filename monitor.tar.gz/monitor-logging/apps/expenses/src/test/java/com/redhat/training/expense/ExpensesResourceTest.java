package com.redhat.training.expense;

import io.quarkus.test.junit.QuarkusTest;


@QuarkusTest
public class ExpensesResourceTest {
}

